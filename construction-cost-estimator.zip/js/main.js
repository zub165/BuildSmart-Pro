// Cost calculation function
function calculateCost(propertySize, constructionType, location) {
    const baseRates = {
        '5-marla': { grey: 2500000, finishing: 3500000 },
        '10-marla': { grey: 4500000, finishing: 6000000 },
        '1-kanal': { grey: 8000000, finishing: 11000000 }
    };
    
    const locationMultipliers = {
        'karachi': 1.2,
        'lahore': 1.1,
        'islamabad': 1.3,
        'default': 1.0
    };
    
    const multiplier = locationMultipliers[location] || locationMultipliers['default'];
    return baseRates[propertySize][constructionType] * multiplier;
}

// Material data
const materials = [
    {
        name: "Cement (50kg bag)",
        price: "PKR 1,100",
        trend: "up",
        change: "+5%",
        suppliers: [
            { name: "Bestway Cement", contact: "021-111111111" },
            { name: "Lucky Cement", contact: "021-222222222" }
        ],
        updated: "2024-03-28"
    },
    {
        name: "Steel (per ton)",
        price: "PKR 250,000",
        trend: "down",
        change: "-2%",
        suppliers: [
            { name: "Agha Steel", contact: "021-333333333" },
            { name: "Amreli Steel", contact: "021-444444444" }
        ],
        updated: "2024-03-28"
    }
];

// Contractor data
const contractors = [
    {
        name: "Ali Construction Services",
        rating: 4.7,
        reviews: 128,
        specializations: ["Residential", "5+ Years Experience"],
        portfolio: [
            "https://via.placeholder.com/300x200",
            "https://via.placeholder.com/300x200"
        ]
    },
    {
        name: "BuildRight Solutions",
        rating: 4.5,
        reviews: 95,
        specializations: ["Commercial", "10+ Years Experience"],
        portfolio: [
            "https://via.placeholder.com/300x200",
            "https://via.placeholder.com/300x200"
        ]
    }
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize cost calculator
    initializeCostCalculator();
    
    // Initialize material prices
    initializeMaterialPrices();
    
    // Initialize contractor directory
    initializeContractorDirectory();
    
    // Initialize cost chart
    initializeCostChart();
});

// Cost Calculator Initialization
function initializeCostCalculator() {
    const inputs = ['property-size', 'construction-type', 'location'];
    
    inputs.forEach(id => {
        document.getElementById(id).addEventListener('change', updateCostEstimate);
    });
    
    // Initial calculation
    updateCostEstimate();
}

function updateCostEstimate() {
    const propertySize = document.getElementById('property-size').value;
    const constructionType = document.getElementById('construction-type').value;
    const location = document.getElementById('location').value;
    
    const cost = calculateCost(propertySize, constructionType, location);
    document.getElementById('cost-estimate').textContent = `PKR ${cost.toLocaleString()}`;
    
    // Update cost breakdown chart
    updateCostChart(cost);
}

// Material Prices Initialization
function initializeMaterialPrices() {
    const materialList = document.getElementById('material-list');
    
    materials.forEach(material => {
        const card = createMaterialCard(material);
        materialList.appendChild(card);
    });
}

function createMaterialCard(material) {
    const card = document.createElement('div');
    card.className = 'material-card';
    
    const trendIcon = material.trend === 'up' ? '↑' : '↓';
    const trendColor = material.trend === 'up' ? 'var(--danger-color)' : 'var(--success-color)';
    
    card.innerHTML = `
        <h3>${material.name}</h3>
        <p class="price">${material.price}</p>
        <p class="trend" style="color: ${trendColor}">
            ${trendIcon} ${material.change}
        </p>
        <div class="suppliers">
            <h4>Suppliers:</h4>
            <ul>
                ${material.suppliers.map(supplier => `
                    <li>${supplier.name} - ${supplier.contact}</li>
                `).join('')}
            </ul>
        </div>
        <p class="updated">Last updated: ${material.updated}</p>
    `;
    
    return card;
}

// Contractor Directory Initialization
function initializeContractorDirectory() {
    const contractorList = document.getElementById('contractor-list');
    
    contractors.forEach(contractor => {
        const card = createContractorCard(contractor);
        contractorList.appendChild(card);
    });
}

function createContractorCard(contractor) {
    const card = document.createElement('div');
    card.className = 'contractor-card';
    
    const stars = '★'.repeat(Math.floor(contractor.rating)) + '☆'.repeat(5 - Math.floor(contractor.rating));
    
    card.innerHTML = `
        <div class="rating">${contractor.rating} ${stars} (${contractor.reviews} reviews)</div>
        <h4>${contractor.name}</h4>
        <div class="specializations">
            ${contractor.specializations.map(spec => `
                <span class="badge">${spec}</span>
            `).join('')}
        </div>
        <div class="portfolio">
            ${contractor.portfolio.map(img => `
                <img src="${img}" alt="Project sample">
            `).join('')}
        </div>
        <button class="btn-contact">Request Quote</button>
    `;
    
    return card;
}

// Cost Chart Initialization
function initializeCostChart() {
    const ctx = document.getElementById('costChart').getContext('2d');
    window.costChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Materials', 'Labor', 'Design', 'Permits', 'Contingency'],
            datasets: [{
                data: [45, 35, 10, 5, 5],
                backgroundColor: [
                    '#3b82f6',
                    '#f59e0b',
                    '#10b981',
                    '#6366f1',
                    '#f97316'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
}

function updateCostChart(totalCost) {
    const materials = totalCost * 0.45;
    const labor = totalCost * 0.35;
    const design = totalCost * 0.10;
    const permits = totalCost * 0.05;
    const contingency = totalCost * 0.05;
    
    window.costChart.data.datasets[0].data = [
        materials,
        labor,
        design,
        permits,
        contingency
    ];
    
    window.costChart.update();
} 